/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask1_semester2;

import java.util.Scanner;


public class Bird extends Animal{ //"Bird" is the child class of "Animal" - the parent class
    
    //Decalring Variables 
    private int colour;
    
    @Override
    public void input(){
        
        super.input();
        
        Scanner sc = new Scanner(System.in);
        
        //Input and validate the feather colour
        while(true){
        System.out.println("Enter the feather colour(1 = grey, 2 = white, 3 = black) of the bird:");
        
        colour = sc.nextInt();
        
        if (colour >= 1 && colour <=3){
            
            break; //it is a valid input, therefore exit the loop
            
        } else{
            
            System.out.println("That is an invalid colour value.");
            }
        }
    }
    
    @Override
    public void output(){
        
        super.output();
        
        String colourName;
        
        if(colour==1){
            colourName = "Grey";
        } else if(colour==2) {
            colourName = "White";
        } else{
            colourName = "Black";
        }
        System.out.println("Feather Colour of Bird: " +colourName);
    }
    
}
