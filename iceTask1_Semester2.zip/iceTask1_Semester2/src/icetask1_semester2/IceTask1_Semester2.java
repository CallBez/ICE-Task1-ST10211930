/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask1_semester2;



public class IceTask1_Semester2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //object for child class
        Bird brd = new Bird();
        
        //object for child class
        Reptile rept = new Reptile();
        
        //Start of the user input for the bird information
        System.out.println("Please enter details of the bird:");
        brd.input();
        
        //output of the bird information 
        System.out.println("\nBird details: ");
        brd.output();
        
        //Start of the user input for the reptile information
        System.out.println("\nPlease enter details of the reptile:");
        rept.input();
        
        //output of the reptile information 
        System.out.println("Reptile details: ");
        rept.output();
        
    }
    
}
