/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask1_semester2;

import java.util.Scanner;


public class Animal {
    
    //Declaring Variables --> used protected access modifers so that the child class can access these variables 
    protected int IDtag; //number that zoo uses to catalogue their animals
    
    protected String species;
    
    public void input(){
        
        //Scanner
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("Enter the animal ID Tag:");
        
        IDtag = sc.nextInt();
        
        sc.nextLine();
        
        System.out.println("Enter the animal species:");
        
        species = sc.nextLine();
    }
    
    public void output(){
        
        System.out.println("ID Tag: " + IDtag);
        
        System.out.println("Species: " + species);
    }
    
}
