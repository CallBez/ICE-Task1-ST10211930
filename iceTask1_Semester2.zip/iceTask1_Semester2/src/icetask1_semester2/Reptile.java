/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask1_semester2;

import java.util.Scanner;


public class Reptile extends Animal {
    
    //Declare variables 
    private double bloodTemp;
    
    @Override
    public void input(){
        
    super.input();
    
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Enter the blood temperature of the reptile:");
    
    bloodTemp = sc.nextDouble();
    
    }
    
    @Override
    public void output(){
        
        super.output();
        
        System.out.println("Blood temprature of reptile: " +bloodTemp);
    }
}
